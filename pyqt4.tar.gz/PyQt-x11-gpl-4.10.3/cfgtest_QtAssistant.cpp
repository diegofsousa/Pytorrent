#include <qassistantclient.h>

int main(int, char **)
{
    new QAssistantClient("foo");
}
