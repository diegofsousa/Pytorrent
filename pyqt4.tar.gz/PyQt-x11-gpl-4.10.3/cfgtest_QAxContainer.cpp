#include <qaxobject.h>

int main(int, char **)
{
    new QAxObject();
}
