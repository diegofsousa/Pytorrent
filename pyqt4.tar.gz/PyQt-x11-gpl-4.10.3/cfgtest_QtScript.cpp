#include <qscriptengine.h>

int main(int, char **)
{
    new QScriptEngine();
}
