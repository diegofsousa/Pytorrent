#include <QExtensionFactory>

int main(int, char **)
{
    new QExtensionFactory();
}
